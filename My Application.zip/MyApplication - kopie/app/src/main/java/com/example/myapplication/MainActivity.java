package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import java.io.File;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        EditText username = (EditText) findViewById(R.id.etInlognaam);
        EditText password = (EditText) findViewById(R.id.etWachtwoord);

        String gebruiker = username.getText().toString();
        String ww = password.getText().toString();

        SQLiteDatabase gebruikersDB = this.openOrCreateDatabase("gebruikersDB", MODE_PRIVATE, null);
        File dbFile = getDatabasePath("gebruikersDB");

        if (dbFile.exists()) {
            Log.i("database", "bestaat");
            Log.i("Path to database ", dbFile.getPath());
        } else {
            Log.i("database", "bestaat niet");
        }

        gebruikersDB.execSQL(
                "CREATE TABLE IF NOT EXISTS gegevens (inlognaam VARCHAR, wachtwoord VARCHAR);"
        );

        switch (view.getId()) {
            case R.id.registreren:
                Log.d("test", "registreren button geklikt");
                String sql = "INSERT or REPLACE INTO gegevens (inlognaam, wachtwoord) " +
                        "VALUES ('" + gebruiker + "', '" + ww + "');";
                gebruikersDB.execSQL(sql);
                break;

            case R.id.inloggen:
                Log.d("test", "inloggen button geklikt");

                String table = "gegevens";
                String[] columnsToReturn = { "wachtwoord" };
                String selection = "inlognaam = ?";
                String[] selectionArgs = { gebruiker };

                Cursor cursor = null;

                try {
                    cursor = gebruikersDB.query(
                            table,
                            columnsToReturn,
                            selection,
                            selectionArgs,
                            null,
                            null,
                            null
                    );

                    // Check if the cursor contains any rows before moving
                    if (cursor != null && cursor.getCount() > 0) {
                        cursor.moveToFirst(); // Move to the first row

                        String storedPassword = cursor.getString(cursor.getColumnIndex("wachtwoord"));
                        Log.d("Stored password", storedPassword);

                        if (storedPassword.equals(ww)) {
                            Log.d("Login", "Inloggen succesvol");

                            // Starting MainActivity2 after successful login
                            Intent intent = new Intent(this, MainActivity2.class);
                            startActivity(intent);
                        } else {
                            Log.d("Login", "Inloggen mislukt");
                        }
                    } else {
                        Log.d("Login", "Gebruiker niet gevonden");
                        // Optionally, show a message to the user
                    }
                } catch (Exception e) {
                    Log.e("Database error", e.toString());
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
                break;
        }
    }
