package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {
    EditText etStad, etLand;
    TextView tvResult;
    private final String url = "http://api.openweathermap.org/data/2.5/weather";
    private final String appid = "7236f738b3c2a5a273b8919f2b1656ba";
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        etStad = findViewById(R.id.etStad);
        etLand = findViewById(R.id.etLand);
        tvResult = findViewById(R.id.tvResult);
    }

    public void getWeatherDetails(View view) {
        String tempUrl;
        String Stad = etStad.getText().toString().trim();
        String Land = etLand.getText().toString().trim();

        if (Stad.isEmpty()) {
            tvResult.setText("Stad veld mag niet leeg zijn!");
            return;
        }

        if (!Land.isEmpty()) {
            tempUrl = url + "?q=" + Stad + "," + Land + "&appid=" + appid;
        } else {
            tempUrl = url + "?q=" + Stad + "&appid=" + appid;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, tempUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray weatherArray = jsonResponse.getJSONArray("weather");
                            JSONObject weatherObject = weatherArray.getJSONObject(0);
                            String description = weatherObject.getString("description");

                            JSONObject mainObject = jsonResponse.getJSONObject("main");
                            double temp = mainObject.getDouble("temp") - 273.15;
                            double feelsLike = mainObject.getDouble("feels_like") - 273.15;
                            int humidity = mainObject.getInt("humidity");
                            int pressure = mainObject.getInt("pressure");

                            JSONObject windObject = jsonResponse.getJSONObject("wind");
                            String windSpeed = windObject.getString("speed");

                            JSONObject cloudsObject = jsonResponse.getJSONObject("clouds");
                            String cloudiness = cloudsObject.getString("all");

                            JSONObject sysObject = jsonResponse.getJSONObject("sys");
                            String countryName = sysObject.getString("country");

                            String cityName = jsonResponse.getString("name");

                            String output = "Current weather of " + cityName + " (" + countryName + ")"
                                    + "\n Temp: " + df.format(temp) + " °C"
                                    + "\n Feels Like: " + df.format(feelsLike) + " °C"
                                    + "\n Humidity: " + humidity + "%"
                                    + "\n Description: " + description
                                    + "\n Wind Speed: " + windSpeed + " m/s"
                                    + "\n Cloudiness: " + cloudiness + "%"
                                    + "\n Pressure: " + pressure + " hPa";

                            tvResult.setTextColor(Color.rgb(68, 134, 199));
                            tvResult.setText(output);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Error parsing data", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("VolleyError", error.toString());
                        Toast.makeText(getApplicationContext(), "Error fetching data: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}

